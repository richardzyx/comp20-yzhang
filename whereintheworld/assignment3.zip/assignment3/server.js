// Initialization
var express = require('express');
var bodyParser = require('body-parser');
var validator = require('validator'); // See documentation at https://github.com/chriso/validator.js
var app = express();
// See https://stackoverflow.com/questions/5710358/how-to-get-post-query-in-express-node-js
app.use(bodyParser.json());
// See https://stackoverflow.com/questions/25471856/express-throws-error-as-body-parser-deprecated-undefined-extended
app.use(bodyParser.urlencoded({ extended: true }));
var http = require('http');
var options = {
  host: 'developer.mbta.com',
  port: 80,
  path: '/lib/rthr/red.json'
};

// Mongo initialization
var mongoUri = process.env.MONGOLAB_URI || process.env.MONGOHQ_URL || 'mongodb://localhost/test';
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function(error, databaseConnection) {
	db = databaseConnection;
});

app.post('/sendLocation', function(request, response) {
	response.header("Access-Control-Allow-Origin", "*");
	response.header("Access-Control-Allow-Headers", "X-Requested-With");
	var login = request.body.login;
	var lat = request.body.lat;
	var lng = request.body.lng;

	if (login == undefined || lat == undefined || lng == undefined) {
		response.send(500);
	}
	else {
		lat=parseFloat(lat);
		lng=parseFloat(lng);
		var toInsert = {
			"login": login,
			"lat": lat,
			"lng": lng,
			"created_at": (new Date()).toJSON(),
		};
		db.collection('locations', function(er, collection) {
			var id = collection.insert(toInsert, function(err, saved) {
				if (err) {
					response.send(500);
				}
				else {
					resJson = [];
					db.collection('locations', function(er, collection) {
	    				collection.find({}).sort({created_at: -1}).limit(100).toArray(function(err, docs) {
	    					if(!err){
	    						for (var count =0; count<docs.length; count++){
	    							resJson.push({"login": docs[count].login, "lat": docs[count].lat, "lng": docs[count].lng, "created_at": docs[count
	    								].created_at, "_id": docs[count]._id});
	    						}
	    						response.send(JSON.stringify({"characters":[], "students":resJson}));
	    					} else {
	    						response.send(500);
	    					}
						});
					});
		    	}
			});
		});
	}
});

app.get('/locations.json', function(request, response) {
	response.header("Access-Control-Allow-Origin", "*");
	response.header("Access-Control-Allow-Headers", "X-Requested-With");
	var resJson = [];

	if (request.query.login == undefined){
		response.send(resJson);
	} else {
		db.collection('locations', function(er, collection) {
	    	collection.find({"login": request.query.login}).sort({created_at: -1}).limit(100).toArray(function(err, docs) {
	    		if(!err){
	    			for (var count =0; count<docs.length; count++){
	    				resJson.push({"login": docs[count].login, "lat": docs[count].lat, "lng": docs[count].lng, "created_at": docs[count].created_at, "_id": docs[count]._id});
	    			}
	    			response.send(JSON.stringify(resJson));
	    		} else {
	    			response.send(500);
	    		}
			});
		});
	}
	
});

app.get('/', function(request, response) {
	response.set('Content-Type', 'text/html');
	var indexPage = '';
	var resJson = [];
	db.collection('locations', function(er, collection) {
		collection.find().sort({created_at: -1}).toArray(function(err, docs) {
			if (!err) {
				indexPage += "<!DOCTYPE HTML><html><head><title>Check-ins?</title></head><body><h1>Check-ins?</h1>";
				for (var count = 0; count < docs.length; count++) {
					resJson=[{"login": docs[count].login, "lat": docs[count].lat, "lng": docs[count].lng, "created_at": docs[count].created_at, "_id": docs[count]._id}];
					indexPage += "<p>Your check-in info: " + JSON.stringify(resJson) + "!</p>";
				}
				indexPage += "</body></html>"
				response.send(indexPage);
			} else {
				response.send('<!DOCTYPE HTML><html><head><title>Check-ins?</title></head><body><h1>Nah not working!</h1></body></html>');
			}
		});
	});
});

//This part it mainly from the Piazza answer
app.get('/redline.json', function(request, response) {
	response.setHeader("Content-Type", "application/json");
	http.get(options, function(apiresponse) {
		var data = '';
		console.log("Got response: " + response.statusCode);
		// Okay, we got some data.  Data is piece-mailed!  That is, you will not get all the data in one swoop!
		apiresponse.on('data', function(chunk) {
			data += chunk;
		});
		// So we finished getting all the data (think of this as readyState = 4), now we can send response data safely!
	  	apiresponse.on('end', function() {
	    	response.send(data);
	  	});
	}).on('error', function(e) {
	  console.log("Got error: " + e.message);
	});
});

// Oh joy! http://stackoverflow.com/questions/15693192/heroku-node-js-error-web-process-failed-to-bind-to-port-within-60-seconds-of
app.listen(process.env.PORT || 3000);


