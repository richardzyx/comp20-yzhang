This is the Assi 3 Where in the World for Comp20
====================================
All aspects of the work have been correctly implemented, with console log messages saved intentionally for future debugging purposes. The assignment is completed indepently without any collaboration or discussion with anyone. I have saved the comment lines from the example given by Ming for future references.

I have spent about two nights and a day on this assignment because I spent enourmous amount of time fixing my conflict port problem with my other on going applications. I also had to reinstall mongodb twice and reconfigure various settings in order for node and mongo to work.